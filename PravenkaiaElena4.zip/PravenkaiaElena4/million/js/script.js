var event, i, info_text , sum = 0;
/*

event ответ юзера
info_text доп. сообзщене юзеру
sum накопленная сумма

*/

console.log('texts.length');
console.log(texts.length);

for (i = 0; i < texts.length; i++) {
    
    if (i == 0) 
        info_text = 'Игра "Хочешь стать миллионером?"\n';
    else 
        info_text = '';
    
    event = question(texts, i, sum, info_text); //генерация вопроса, запрос ответа 
        
    if (event == -1) { //пользователь выходит из игры
        break;
    }
    else if (!checkEnter(event)) { // ошибки ввода
        event = question(texts,i, sum, 'ОШИБКА ВВОДА\n');  
        i--; //возврат на этап цикла
    }
    
    else {
        if (texts[i].rightAnswer == event) 
                    sum += texts[i].price; // накопленная сумма выигрыша
        else {
            sum = 'Накоплено: ' + sum;
            sum += '\nОтвет неверный!\nВы проиграли!\nСпасибо за игру!'
            alert(sum);
            break;
        }
    }

} 

//Функция генерации вопоса

function question(ar,i, playSum, info) {
    var eventF, k;
    
        eventF = info; //доплнительный текст
        if (playSum > 0) 
            eventF += 'Накоплено ' + playSum +'\n';
        eventF += texts[i].quest;
        eventF += '\n' + texts[i].price;
    
        for (k = 0; k < 4; k++) {
            eventF += '\n' + texts[i].variants[k];
            
        }
    
    eventF += '\n-1 - Выход из игры';
    return prompt(eventF);
}

// Проверка допустимости введенных символов
function checkEnter(simbol) {
    
    switch (simbol) {
            
        case 'A': 
            return true;
        case 'B': 
            return true;
            break;
        case 'C': 
            return true;
            break;
        case 'D': 
            return true;
            break;
        case -1:
            return -1;  //выход из игры
            break;
            
        default:
           return false;
    }
}