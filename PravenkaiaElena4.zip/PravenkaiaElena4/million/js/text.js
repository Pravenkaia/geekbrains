


//функция создания объекта
make_quest = function(
            quest,
            price,
            rightAnswer,
            variants
            ) {
            this.quest       = quest;
            this.price       = price;
            this.rightAnswer = rightAnswer;
            this.variants    = variants;
}

var texts = new Array();

var quest1 = new make_quest(
        'Как называют манекенщицу супер-класса?', 
        100, 
        'A',
        ['A: Топ-модель',' B: Тяп-модель', 'C: Поп-модель', 'D: Ляп-модель']
    );

texts.push(quest1);

var quest2 = new make_quest(
    'Кто вырос в джунглях среди диких зверей?',
    100,
    'B',
    ['A: Колобок', 'B: Маугли', 'C: Бэтмен', 'D: Чарльз Дарвин']
);

texts.push(quest2);

var quest3 = new make_quest(
    'Как называлась детская развлекательная программа, популярная в прошлые годы?',
    100,
    'A',
    ['A: АБВГДейка', 'B: ЁКЛМНейка', 'C: ЁПРСТейка', 'D: ЁЖЗИКейка']
);

texts.push(quest3);

var quest4 = new make_quest(
    'Как звали невесту Эдмона Дантеса, будущего графа Монте-Кристо?',
    200,
    'A',
    ['A: Мерседес', 'B: Тойота', 'C: Хонда', 'D: Лада']
);

texts.push(quest4);

var quest5 = new make_quest(
    'Какой цвет получается при смешении синего и красного?',
    200,
    'B',
    ['A: Коричневый', 'B: Фиолетовый', 'C: Зелёный', 'D: Голубой']
);

texts.push(quest5);

var quest6 = new make_quest(
    'Из какого мяса традиционно готовится начинка для чебуреков?',
    200,
    'A',
    ['A: Баранина', 'B: Свинина', 'C: Телятина', 'D: Конина']
);

texts.push(quest6);

var quest7 = new make_quest(
    'Какой народ придумал танец чардаш?',
    300,
    'A',
    ['A: Венгры', 'B: Румыны', 'C: Чехи', 'D: Молдаване']
);

texts.push(quest7);

var quest8 = new make_quest(
    'Изучение соединений какого элемента является основой органической химии?',
    300,
    'B',
    ['A: Кислород', 'B: Углерод', 'C: Азот', 'D: Кремний']
);

texts.push(quest8);

var quest9 = new make_quest(
    'Кто открыл тайну трёх карт графине из «Пиковой дамы» А. С. Пушкина?',
    300,
    'C',    
    ['A: Казанова', 'B: Калиостро', 'C: Сен-Жермен', 'D: Томас Воган']
);

texts.push(quest9);


var quest10 = new make_quest(
    'В какой стране была пробурена первая промышленная нефтяная скважина?',
    300,
    'D',
    ['A: Кувейт', 'B: Иран', 'C: Ирак', 'D: Азербайджан']
);

texts.push(quest10);



console.log(texts);

/*










*/